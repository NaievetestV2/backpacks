# revoke the advancement, so it can be used again
advancement revoke @s only bundle:internal_actions/chest/bundle

# execute a raycast to get the position of the clicked chest
execute as @s at @s anchored eyes positioned ^ ^ ^ anchored feet run function bundle:raycast/start_ray

# stop the sound of the chest opening
stopsound @s block block.chest.open

# copy the "bundle_contents" component into the marker's data
data modify entity @n[type=marker,tag=container.marker] data.bundle_contents set from entity @s equipment.offhand.components."minecraft:bundle_contents"

# convert the stored "bundle_contents" component into a readable format for placed containers and fill the current container with the items from the marker's "data.items"
execute as @n[type=marker,tag=container.marker] at @s run function bundle:chest/transfer/bundle_contents

# copy the id of the bundle to switch it to the player's mainhand
data modify entity @n[type=marker,tag=container.marker] data.Offhand.ItemId set from entity @s equipment.offhand.id
function bundle:chest/transfer/replace/id with entity @n[type=marker,tag=container.marker] data.Offhand

# empty the player's off-hand
item replace entity @s[gamemode=!creative] weapon.offhand with air

# play the 'bundle insert item' sound
execute as @n[type=marker,tag=container.marker] at @s run function bundle:chest/transfer/play_final_effects
