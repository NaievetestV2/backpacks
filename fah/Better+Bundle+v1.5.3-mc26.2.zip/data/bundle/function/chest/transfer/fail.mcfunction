# revoke the advancement, so it can be used again
advancement revoke @s only bundle:internal_actions/chest/fail

# stop the chest opening sound
stopsound @s block block.chest.open

# message
tellraw @s [{"color":"dark_gray","italic":false,"text":"["},{"color":"gold","italic":false,"text":"Better Bundle"},{"italic":false,"text":"] "},{"color":"red","italic":false,"text":"The chest you clicked on is not empty. To\nquickly deposit items into a chest, make sure it's empty first."}]

# sound
execute at @s run playsound item.bundle.insert_fail player @a[distance=..16] ~ ~ ~ 1 1

## IMPORTANTE!
# RICORDA CHE HAI CAMBIATO LA SOURCE DEL SUONO
# DA MASTER A PLAYER DOPO CHE HAI PUBBLICATO LA VERSIONE 1.5.2