# sounds
playsound item.bundle.insert master @a[distance=..16] ~ ~ ~ 1 1 1
playsound minecraft:entity.illusioner.mirror_move master @a[distance=..16] ~ ~ ~ 1 2 1

# particles
particle bubble_pop ~ ~.775 ~ 0.125 0.125 0.125 0 16 force @a[distance=..16]

# kill the current entity as it has fulfilled its purpose
kill @s
