# replace the current chest to delete its content and close the gui
function bundle:chest/close/detect_direction

# set a 'slots' array from 0 to 26 (single container slots) in the marker's "data.items"
data modify entity @s data.items set value [\
{Slot:0b},\
{Slot:1b},\
{Slot:2b},\
{Slot:3b},\
{Slot:4b},\
{Slot:5b},\
{Slot:6b},\
{Slot:7b},\
{Slot:8b},\
{Slot:9b},\
{Slot:10b},\
{Slot:11b},\
{Slot:12b},\
{Slot:13b},\
{Slot:14b},\
{Slot:15b},\
{Slot:16b},\
{Slot:17b},\
{Slot:18b},\
{Slot:19b},\
{Slot:20b},\
{Slot:21b},\
{Slot:22b},\
{Slot:23b},\
{Slot:24b},\
{Slot:25b},\
{Slot:26b}\
]

# get the items from the "data.bundle_contents" into the marker's "data.items"
data modify entity @s data.items.[0] merge from entity @s data.bundle_contents.[0]
data modify entity @s data.items.[1] merge from entity @s data.bundle_contents.[1]
data modify entity @s data.items.[2] merge from entity @s data.bundle_contents.[2]
data modify entity @s data.items.[3] merge from entity @s data.bundle_contents.[3]
data modify entity @s data.items.[4] merge from entity @s data.bundle_contents.[4]
data modify entity @s data.items.[5] merge from entity @s data.bundle_contents.[5]
data modify entity @s data.items.[6] merge from entity @s data.bundle_contents.[6]
data modify entity @s data.items.[7] merge from entity @s data.bundle_contents.[7]
data modify entity @s data.items.[8] merge from entity @s data.bundle_contents.[8]
data modify entity @s data.items.[9] merge from entity @s data.bundle_contents.[9]
data modify entity @s data.items.[10] merge from entity @s data.bundle_contents.[10]
data modify entity @s data.items.[11] merge from entity @s data.bundle_contents.[11]
data modify entity @s data.items.[12] merge from entity @s data.bundle_contents.[12]
data modify entity @s data.items.[13] merge from entity @s data.bundle_contents.[13]
data modify entity @s data.items.[14] merge from entity @s data.bundle_contents.[14]
data modify entity @s data.items.[15] merge from entity @s data.bundle_contents.[15]
data modify entity @s data.items.[16] merge from entity @s data.bundle_contents.[16]
data modify entity @s data.items.[17] merge from entity @s data.bundle_contents.[17]
data modify entity @s data.items.[18] merge from entity @s data.bundle_contents.[18]
data modify entity @s data.items.[19] merge from entity @s data.bundle_contents.[19]
data modify entity @s data.items.[20] merge from entity @s data.bundle_contents.[20]
data modify entity @s data.items.[21] merge from entity @s data.bundle_contents.[21]
data modify entity @s data.items.[22] merge from entity @s data.bundle_contents.[22]
data modify entity @s data.items.[23] merge from entity @s data.bundle_contents.[23]
data modify entity @s data.items.[24] merge from entity @s data.bundle_contents.[24]
data modify entity @s data.items.[25] merge from entity @s data.bundle_contents.[25]
data modify entity @s data.items.[26] merge from entity @s data.bundle_contents.[26]

# set the chest items from the marker's "data.items"
data modify block ~ ~ ~ Items set from entity @s data.items
