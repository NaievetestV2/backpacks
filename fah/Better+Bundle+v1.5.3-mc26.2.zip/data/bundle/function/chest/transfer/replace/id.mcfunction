# give the player a new bundle with the right id in their main-hand
$item replace entity @s[gamemode=!creative] weapon.mainhand with $(ItemId)
