##> Detect the direction the chest is facing and replace it accordingly

# north
execute if block ~ ~ ~ chest[facing=north] run function bundle:chest/close/north

# south
execute if block ~ ~ ~ chest[facing=south] run function bundle:chest/close/south

# west
execute if block ~ ~ ~ chest[facing=west] run function bundle:chest/close/west

# east
execute if block ~ ~ ~ chest[facing=east] run function bundle:chest/close/east
