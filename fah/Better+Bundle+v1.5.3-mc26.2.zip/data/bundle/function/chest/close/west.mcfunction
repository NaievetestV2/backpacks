# set air to close the gui and then place a new chest
setblock ~ ~ ~ air strict

setblock ~ ~ ~ chest[facing=west] strict
