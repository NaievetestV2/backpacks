# revoke the advancement(s)
advancement revoke @s only bundle:internal_actions/bundle/chest
advancement revoke @s only bundle:internal_actions/bundle/replace
advancement revoke @s only bundle:internal_actions/chest/bundle
advancement revoke @s only bundle:internal_actions/chest/fail
advancement revoke @s only bundle:recipe/bundle
advancement revoke @s only bundle:use_bundle

# remove scoreboard(s)
scoreboard objectives remove bundlecasttemp

# kill any conatiner marker left
kill @e[type=marker,nbt={Tags:["container.marker"]}]

# reset message
tellraw @a [{"text":"'"},{"text":"Better Bundle","color":"gray"},{"text":"'"},{"text":" Reset","color":"dark_aqua"},{"text":" Succesfully!","color":"green"}]

reload
