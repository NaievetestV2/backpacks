# print an error message
tellraw @p[tag=bb_transfer] [{"text":"[","color":"dark_gray"},{"text":"Better Bundle","color":"gold","italic":false},{"text":"] ","color":"dark_gray"},{"text":"There are one or more bundles inside the\nchest; please remove them to bundle the chest content.","color":"red","italic":false}]

# play the bundle error sound
playsound item.bundle.insert_fail player @a[distance=..16] ~ ~ ~ 1 1


## IMPORTANTE!
# RICORDA CHE HAI CAMBIATO LA SOURCE DEL SUONO
# DA MASTER A PLAYER DOPO CHE HAI PUBBLICATO LA VERSIONE 1.5.2