# change the custom data on the new bundle item to "doesn't store"
data modify entity @s[nbt={Item:{components:{"minecraft:custom_data":{storing:true},"minecraft:bundle_contents":[{}]}}}] Item.components."minecraft:custom_data" set value {"storing":false}

# if the items have been succesfully copied to the bundle, proceeds to replace the current chest to delete its content and to close the gui
execute as @s[nbt={Item:{components:{"minecraft:custom_data":{storing:false},"minecraft:bundle_contents":[{}]}}}] if block ~ ~ ~ chest run function bundle:chest/close/detect_direction

# unlock the chest in case the copy operation fails
data remove block ~ ~ ~ lock

# play a sound effect
execute as @s[nbt={Item:{components:{"minecraft:custom_data":{storing:false},"minecraft:bundle_contents":[{}]}}}] run function bundle:new_bundle/transfer/play_final_effects
