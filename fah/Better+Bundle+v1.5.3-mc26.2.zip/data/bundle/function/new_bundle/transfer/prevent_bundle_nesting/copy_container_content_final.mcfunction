# check if there is any shulker box containing one or more bundles with items, and if not, copy the items over to the new bundle
execute if block ~ ~ ~ chest unless block ~ ~ ~ chest{Items:[{components:{"minecraft:container":[{item:{components:{"minecraft:bundle_contents":[{}]}}}]}}]} if block ~ ~1 ~ #minecraft:air run data modify entity @s Item.components.minecraft:bundle_contents set from block ~ ~ ~ Items

# output an error message when one or more bundles with items are found inside a shulker inside the current container
execute unless entity @s[nbt={Item:{components:{"minecraft:custom_data":{storing:true},"minecraft:bundle_contents":[{}]}}}] if block ~ ~ ~ chest{Items:[{components:{"minecraft:container":[{item:{components:{"minecraft:bundle_contents":[{}]}}}]}}]} run function bundle:new_bundle/transfer/fail/shulker
