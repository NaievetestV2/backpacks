# if there are no bundles inside the current container, proceeds with the final check
execute if block ~ ~ ~ chest unless items block ~ ~ ~ container.* #minecraft:bundles if block ~ ~1 ~ #minecraft:air run function bundle:new_bundle/transfer/prevent_bundle_nesting/copy_container_content_final

# output an error message when one or more bundles are found in the current container
execute unless entity @s[nbt={Item:{components:{"minecraft:custom_data":{storing:true},"minecraft:bundle_contents":[{}]}}}] if items block ~ ~ ~ container.* #minecraft:bundles run function bundle:new_bundle/transfer/fail/bundle

# call the next function as the newly summoned bundle entity item
function bundle:new_bundle/transfer/step_2
