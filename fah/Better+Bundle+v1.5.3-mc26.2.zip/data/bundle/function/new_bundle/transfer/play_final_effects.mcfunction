# sounds
playsound item.bundle.insert master @a[distance=..16] ~ ~ ~ 1 1 1
playsound minecraft:entity.illusioner.prepare_mirror master @a[distance=..16] ~ ~ ~ 1 2 1

# particles
particle sculk_charge_pop ~ ~.225 ~ 0.125 0.125 0.125 0 16 force @a[distance=..16]
