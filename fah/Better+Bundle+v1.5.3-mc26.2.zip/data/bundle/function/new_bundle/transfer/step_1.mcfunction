# execute a raycast to get the position of the clicked chest
execute as @s at @s anchored eyes positioned ^ ^ ^ anchored feet run function bundle:raycast/start_ray

# add a tag to the current player
tag @s add bb_transfer

# summon the new bundle in which the items will be copied in
execute if items entity @s weapon.mainhand #minecraft:bundles run data modify entity @n[type=marker,tag=container.marker] data.Mainhand.ItemId set from entity @s SelectedItem.id
execute as @n[type=marker,tag=container.marker] at @s run function bundle:new_bundle/transfer/setup/summon_bundle with entity @s data.Mainhand

# copy the content of the container inside the bundle
execute as @n[type=item,nbt={Item:{components:{"minecraft:custom_data":{storing:true}}}}] at @s run function bundle:new_bundle/transfer/prevent_bundle_nesting/copy_container_content_1

# stop the sound of the chest opening and empty the player's hand
stopsound @s block block.chest.open
item replace entity @s weapon.mainhand with air

# kill the current 'container.marker' entity as it has fulfilled its purpose
kill @n[type=marker,tag=container.marker]

# remove the tag used to "track" the current player
tag @s remove bb_transfer
