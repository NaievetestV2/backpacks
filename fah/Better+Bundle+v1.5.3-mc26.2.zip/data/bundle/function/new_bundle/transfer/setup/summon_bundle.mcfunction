# summon the corresponding bundle item
$summon item ~ ~.38 ~ {PickupDelay:40,Motion:[0.0,0.0,0.0],Item:{id:"$(ItemId)",count:1,components:{"minecraft:custom_data":{storing:true}}}}
