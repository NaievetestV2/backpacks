# revoke the advancement, so it can be used again
advancement revoke @s only bundle:internal_actions/bundle/chest

# check if the bundle in the player hand is an empty one, and if so, proceed to transfer the items into it
execute if items entity @s weapon.mainhand #minecraft:bundles unless items entity @s weapon.mainhand #minecraft:bundles[minecraft:custom_data~{storing:false}|!minecraft:bundle_contents=[]] run function bundle:new_bundle/transfer/step_1
