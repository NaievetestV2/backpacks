#Mark the ray as having found a block.

scoreboard players set #hit bundlecasttemp 1

#> Execute Custom Commands

# Summon a marker to retrive the chest position
execute align xyz run summon marker ~.5 ~.5 ~.5 {Tags:["container.marker"]}

# lock the chest to prevent item duplication
data modify block ~ ~ ~ lock set value {components:{custom_data:{bundle_key:true}}}
