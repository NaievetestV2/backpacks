#Run a function if a block was successfully detected.

execute if block ~ ~ ~ #bundle:valid_containers run function bundle:raycast/hit_block
scoreboard players add #distance bundlecasttemp 1

#Advance forward and run the ray again if no entity and/or block was found.

execute if score #hit bundlecasttemp matches 0 if score #distance bundlecasttemp matches ..50 positioned ^ ^ ^0.1 run function bundle:raycast/ray
