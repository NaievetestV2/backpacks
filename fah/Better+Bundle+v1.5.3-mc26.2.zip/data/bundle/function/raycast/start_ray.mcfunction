#Setting up the raycasting data.

tag @s add bundleray
scoreboard players set #hit bundlecasttemp 0
scoreboard players set #distance bundlecasttemp 0

#Activating the raycast. This function will call itself until it is done.

function bundle:raycast/ray

#Raycasting finished, removing tag from the raycaster.

tag @s remove bundleray