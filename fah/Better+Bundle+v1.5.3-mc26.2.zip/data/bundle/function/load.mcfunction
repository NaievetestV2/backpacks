# add the scoreaboards
scoreboard objectives add bundlecasttemp dummy

# load message
#tellraw @a [{"text":"'"},{"text":"Nico's DataVerse","color":"dark_aqua","bold":true},{"text":" - ","color":"white"},{"text":"Better Bundle","color":"gray","bold":false,"italic":false},{"text":"'"},{"text":" >> ","color":"white"},{"text":"[1.21.9-1.21.10]","color":"dark_green","bold":true},{"text":"    v1.5.3","color":"gray"}]
