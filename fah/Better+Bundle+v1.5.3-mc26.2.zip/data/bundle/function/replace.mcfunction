# revoke th advancement, so it can be used again
advancement revoke @s only bundle:internal_actions/bundle/replace

# if the bundle the player is holding is empty, and has the custom data "doesn't store", replace it with a corresponding empty one
execute if items entity @s weapon.mainhand #minecraft:bundles[custom_data~{"storing":false}] unless items entity @s weapon.mainhand #minecraft:bundles[!minecraft:bundle_contents=[]] run item modify entity @s weapon.mainhand bundle:remove_custom_data
